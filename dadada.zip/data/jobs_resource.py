from flask_restful import reqparse, abort, Api, Resource
from flask import jsonify, request
from data import db_session
from data.jobs import Jobs


def abort_if_users_not_found(job_id):
    session = db_session.create_session()
    job = session.query(Jobs).get(job_id)
    if not job:
        abort(404, message=f"User {job_id} not found")


class JobsResource(Resource):
    def get(self, job_id):
        abort_if_users_not_found(job_id)
        session = db_session.create_session()
        jobs = session.query(Jobs).get(job_id)
        return jsonify({'jobs': jobs.to_dict()})

    def delete(self, job_id):
        abort_if_users_not_found(job_id)
        session = db_session.create_session()
        job = session.query(Jobs).get(job_id)
        session.delete(job)
        session.commit()
        return jsonify({'success': 'OK'})


class JobsListResource(Resource):
    def get(self):
        session = db_session.create_session()
        jobs = session.query(Jobs).all()
        return jsonify({'jobs': [item.to_dict() for item in jobs]})

    def post(self):
        args = parser.parse_args()
        session = db_session.create_session()
        jobs = Jobs(
            id=args['id'],
            job=args['job'],
            team_leader=args['team_leader'],
            work_size=args['work_size'],
            collaborators=args['collaborators'],
            start_date=args['start_date'],
            end_date=args['end_date'],
            hazard_category=args['hazard_category'],
            is_finished=args['is_finished']
        )
        session.add(jobs)
        session.commit()
        return jsonify({'success': 'OK'})


parser = reqparse.RequestParser()
parser.add_argument('id', required=True, type=str)
parser.add_argument('job', type=str)
parser.add_argument('team_leader', type=str)
parser.add_argument('work_size', type=str)
parser.add_argument('collaborators', type=int)
parser.add_argument('start_date', type=str)
parser.add_argument('end_date', type=str)
parser.add_argument('hazard_category', type=str)
parser.add_argument('is_finished', type=int)
