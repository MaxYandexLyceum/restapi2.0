import requests

a = requests.get("http://127.0.0.1:5000/api/v2/jobs")
print(a.json())
# всё ок
b = requests.get("http://127.0.0.1:5000/api/v2/job")
try:
    print(b.json())
except Exception as e:
    print(e)
# 404
params = {"id": 13, "team_leader": "1", "job": "dadada", "work_size": "123",
          "collaborators": "3", "start_day": "today", "end_day": "today", "hazard_category": "da", "is_finished": 0}
c = requests.post("http://127.0.0.1:5000/api/v2/jobs", json=params)
print(c.json())
# {'success': 'OK'}

params = {"id": 13, "team_leader": "1", "job": "dadada", "work_size": "123",
          "collaborators": "3", "start_day": "today", "end_day": "today", "hazard_category": "da", "is_finished": 0}
c = requests.post("http://127.0.0.1:5000/api/v2/jobs", json=params)
print(c.json())
# {'message': 'Internal Server Error'} - такой id уже существует

c = requests.delete("http://127.0.0.1:5000/api/v2/jobs/12")
print(c.json())
# {'message': 'User 12 not found'}

c = requests.delete("http://127.0.0.1:5000/api/v2/jobs/13")
print(c.json())
# {'success': 'OK'}


