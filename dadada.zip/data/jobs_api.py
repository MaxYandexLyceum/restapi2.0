import flask
from flask import jsonify, request

from . import db_session
from .jobs import Jobs
from .users import User

blueprint = flask.Blueprint(
    'jobs_api',
    __name__,
    template_folder='templates'
)


@blueprint.route('/api/jobs', methods=['POST'])
def get_jobs():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(Jobs).filter(Jobs.id == request.json['id']):
        a = user
    if not a:
        job = Jobs(
            id=request.json['id'],
            team_leader=request.json['team_leader'],
            job=request.json['job'],
            work_size=request.json['work_size'],
            collaborators=request.json['collaborators'],
            hazard_category=request.json['hazard'],
            is_finished=request.json['is_finished']
        )
        db_sess.add(job)
        db_sess.commit()
        print("ok")
    else:
        return jsonify({'ERROR': 'Id already exists'})
    return jsonify({'success': 'OK'})

@blueprint.route('/api/jobs/<int:job_id>')
def get_job(job_id):
    db_sess = db_session.create_session()
    job = db_sess.query(Jobs).get(job_id)
    if not job:
        return jsonify({'error': 'Not found'})
    return jsonify(
        {
            'job': job.to_dict()
        }
    )

@blueprint.route('/api/alljobs')
def get_all_jobs():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return jsonify(
        {
            'jobs':
                [item.to_dict()
                 for item in jobs]
        }
    )


@blueprint.route('/api/jobs/delete/', methods=['POST'])
def delete_job():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(Jobs).filter(Jobs.id == request.json['id']):
        a = user.id
    if not a:
        return jsonify({'ERROR': 'Id does not exist'})
    else:
        job = db_sess.query(Jobs).filter(Jobs.id == int(a)).first()
        db_sess.delete(job)
        db_sess.commit()
    return jsonify({'success': 'OK'})

@blueprint.route('/api/jobs/edit/', methods=['POST'])
def edit_job():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(Jobs).filter(Jobs.id == request.json['id']):
        a = user.id
    if not a:
        return jsonify({'ERROR': 'Job does not exist'})
    else:
        job = db_sess.query(Jobs).filter(Jobs.id == int(a)).first()
        print(job.id)
        job.team_leader = request.json['team_leader']
        job.job = request.json['job']
        job.work_size = request.json['work_size']
        job.collaborators = request.json['collaborators']
        job.hazard_category = request.json['hazard']
        job.is_finished = request.json['is_finished']
        db_sess.commit()
    return jsonify({'success': 'OK'})






### API для User

@blueprint.route('/api/users', methods=['POST'])
def get_users():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(User).filter(User.id == request.json['id']):
        a = user
    if not a:
        user = User(
            id=request.json['id'],
            surname=request.json['surname'],
            name=request.json['name'],
            age=request.json['age'],
            speciality=request.json['speciality'],
            address=request.json['address'],
            email=request.json['email'],
        )
        db_sess.add(user)
        db_sess.commit()
    else:
        return jsonify({'ERROR': 'Id already exists'})
    return jsonify({'success': 'OK'})

@blueprint.route('/api/user/<int:user_id>')
def get_user(user_id):
    db_sess = db_session.create_session()
    user = db_sess.query(User).get(user_id)
    if not user:
        return jsonify({'error': 'Not found'})
    return jsonify(
        {
            'user': user.to_dict()
        }
    )

@blueprint.route('/api/allusers')
def get_all_users():
    db_sess = db_session.create_session()
    users = db_sess.query(User).all()
    return jsonify(
        {
            'users':
                [item.to_dict()
                 for item in users]
        }
    )


@blueprint.route('/api/users/delete/', methods=['POST'])
def delete_user():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(User).filter(User.id == request.json['id']):
        a = user.id
    if not a:
        return jsonify({'ERROR': 'Id does not exist'})
    else:
        user = db_sess.query(User).filter(User.id == int(a)).first()
        db_sess.delete(user)
        db_sess.commit()
    return jsonify({'success': 'OK'})

@blueprint.route('/api/users/edit/', methods=['POST'])
def edit_user():
    if not request.json:
        print(request.json)
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    a = ""
    for user in db_sess.query(User).filter(User.id == request.json['id']):
        a = user.id
    if not a:
        return jsonify({'ERROR': 'Job does not exist'})
    else:
        user = db_sess.query(User).filter(User.id == int(a)).first()
        user.id = request.json['id']
        user.surname = request.json['surname']
        user.name = request.json['name']
        user.age = request.json['age']
        user.speciality = request.json['speciality']
        user.address = request.json['address']
        user.email = request.json['email']
        db_sess.commit()
    return jsonify({'success': 'OK'})
